import pyvisual as pv


def create_page_2_ui(window,ui):
    """
    Create and return UI elements for Page 2.
    :param container: The page widget for Page 2.
    :return: Dictionary of UI elements.
    """
    ui_page = {}
    ui_page["Text_0"] = pv.PvText(container=window, x=123, y=32, width=454,
        height=133, idle_color=(233, 214, 245, 0), text='BIENVENIDO', is_visible=True,
        text_alignment='center', paddings=(0, 0, 0, 0), font='assets/fonts/FiraSans/FiraSans.ttf', font_size=80,
        font_color=(0, 0, 255, 1), bold=False, italic=False, underline=False,
        strikethrough=False, opacity=1, border_color=None, corner_radius=0,
        on_hover=None, on_click=None, on_release=None, tag=None)

    ui_page["lbl_usuario"] = pv.PvText(container=window, x=200, y=179, width=328,
        height=79, idle_color=(194, 155, 215, 0), text='', is_visible=True,
        text_alignment='left', paddings=(0, 0, 0, 0), font='assets/fonts/Lexend/Lexend.ttf', font_size=27,
        font_color=(152, 180, 212, 1), bold=False, italic=False, underline=False,
        strikethrough=False, opacity=1, border_color=None, corner_radius=0,
        on_hover=None, on_click=None, on_release=None, tag='lbl_usuario')

    return ui_page
